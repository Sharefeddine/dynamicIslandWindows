Island for Windows (64-bit Windows 10/11)

Run Island.exe. No browser, Node.js, installer or admin privileges are required.
The program is unsigned and Windows may show a reputation warning.

- Click the island to open or close its Windows media controls.
- Click the JARVIS core to start or stop the microphone.
- Drag the core by its header; click its X to hide it and stop listening.
- Right-click the island or the system-tray icon and choose Exit Island to quit.
- Ctrl+Alt+J toggles listening if the shortcut is available.
- Battery values come from Windows; -- means unavailable.

JARVIS understands a small set of local English commands, not general AI.
It requires a compatible Windows Speech recognizer and microphone permissions.
The app was cross-compiled; its Windows UI and microphone have not been run
in the Linux build environment.

Island.exe SHA-256: ccded4662e299993309353bb061abcf0749bb5813cc7071f08b3d6bcb5870784
